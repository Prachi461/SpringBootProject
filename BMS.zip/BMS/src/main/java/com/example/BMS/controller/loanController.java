package com.example.BMS.controller;

import com.example.BMS.entity.Loan;
import com.example.BMS.service.loanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/loan")
public class loanController {

    @Autowired
    private loanService loanService;

    // Create loan entry
    @PostMapping
    public ResponseEntity<Loan> createOrUpdateLoan(@RequestBody Loan loan) {
        Loan savedLoan = loanService.saveLoan(loan);
        return new ResponseEntity<>(savedLoan, HttpStatus.CREATED);
    }
    
 // Update loan entry
    @PutMapping("/{id}")
    public ResponseEntity<Loan> updateLoan(@PathVariable("id") Long loan_id, @RequestBody Loan loan) {
        Loan updatedLoan = loanService.updateLoan(loan_id, loan);

        if (updatedLoan == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(updatedLoan, HttpStatus.OK);
    }


    // Get all loan entries
    @GetMapping
    public ResponseEntity<List<Loan>> getAllLoan() {
        List<Loan> loan = loanService.getAllLoan();
        return new ResponseEntity<>(loan, HttpStatus.OK);
    }

    // Get any loan entry of choice by ID
    @GetMapping("/{id}")
    public ResponseEntity<Loan> getLoanById(@PathVariable("id") Long loan_id) {
        Loan loan = loanService.getLoanById(loan_id);
        return new ResponseEntity<>(loan, HttpStatus.OK);
    }

    // Delete loan entry by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteEmployee(@PathVariable("id") Long loan_id) {
        loanService.deleteLoan(loan_id);
        return new ResponseEntity<>("Loan entry has been deleted successfully!", HttpStatus.NO_CONTENT);
    }
}
