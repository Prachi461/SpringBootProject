package com.example.BMS.controller;

import com.example.BMS.entity.Account;
import com.example.BMS.service.accountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/accounts")
public class accountController {

    @Autowired
    private accountService accountService;

    //To create account
    @PostMapping
    public ResponseEntity<Account> createOrUpdateAccount(@RequestBody Account account) {
        Account savedAccount = accountService.saveAccount(account);
        return new ResponseEntity<>(savedAccount, HttpStatus.CREATED);
    }

 // Update account by ID
    @PutMapping("/{id}")
    public ResponseEntity<Account> updateAccount(@PathVariable("id") Long acc_id, @RequestBody Account account) {
        Account updatedAccount = accountService.updateAccount(acc_id, account);

        if (updatedAccount == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(updatedAccount, HttpStatus.OK);
    }
    
    // Get all accounts
    @GetMapping
    public ResponseEntity<List<Account>> getAllAccounts() {
        List<Account> accounts = accountService.getAllAccounts();
        return new ResponseEntity<>(accounts, HttpStatus.OK);
    }

    // Get any account by ID
    @GetMapping("/{id}")
    public ResponseEntity<Account> getAccountById(@PathVariable("id") Long acc_id) {
        Account account = accountService.getAccountById(acc_id);
        return new ResponseEntity<>(account, HttpStatus.OK);
    }

    // Delete account by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAccount(@PathVariable("id") Long acc_id) {
        accountService.deleteAccount(acc_id);
        return new ResponseEntity<>("Account has been deleted successfully", HttpStatus.NO_CONTENT);
    }
}
