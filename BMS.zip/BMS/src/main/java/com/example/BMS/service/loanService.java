package com.example.BMS.service;

import com.example.BMS.entity.Loan;
import com.example.BMS.exception.ResourceNotFoundException;
import com.example.BMS.repo.LoanRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class loanService {

    @Autowired
    private LoanRepo loanRepo;

    //To add loan entry
    public Loan saveLoan(Loan loan) {
        return loanRepo.save(loan);
    }
    
  //To update loan entry
    public Loan updateLoan(Long loan_id, Loan loan) {
        Optional<Loan> existingLoanOptional = loanRepo.findById(loan_id);

        if (existingLoanOptional.isPresent()) {
            Loan existingLoan = existingLoanOptional.get();

            existingLoan.setLoan_id(loan.getLoan_id());
            existingLoan.setAmount(loan.getAmount());
      
            return loanRepo.save(existingLoan);
        } else {
            return null;
        }
    }

    // Get all loan entries
    public List<Loan> getAllLoan() {
        return loanRepo.findAll();
    }

    // Get a loan entry by their ID
    public Loan getLoanById(Long loan_id) {
        Optional<Loan> loan = loanRepo.findById(loan_id);
        if (loan.isPresent()) {
            return loan.get();
        } else {
            throw new ResourceNotFoundException("Loan entry not found with id: " + loan_id);
        }
    }

    // Delete loan entry by ID
    public void deleteLoan(Long loan_id) {
        Optional<Loan> loan = loanRepo.findById(loan_id);
        if (loan.isPresent()) {
            loanRepo.deleteById(loan_id);
        } else {
        }
    }
}
