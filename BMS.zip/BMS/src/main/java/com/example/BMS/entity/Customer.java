package com.example.BMS.entity;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@Table(name="customer")
@Getter
@Setter
public class Customer {
	@Id  //Indicating primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY)  //For auto-increment
    private Long customer_id;
    
    @Column(length=20,nullable=false)
    @NotNull(message="Name is required")
    @Size(min=2,max=20)
    private String name;
    
    @Column(length=30,nullable=false,unique=true)
    @NotNull(message="Email is required")
    @Email(message="Email should be valid")
    private String email;
    
    @Column(length=10,nullable=false,unique=true)
    @NotNull(message="Phone number is required")
    @Pattern(regexp="[6789]{1}[0-9]{9}",message="Enter proper phone number")
    private String phone;
            
}

