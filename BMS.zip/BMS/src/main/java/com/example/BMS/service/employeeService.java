package com.example.BMS.service;

import com.example.BMS.entity.Employee;
import com.example.BMS.exception.ResourceNotFoundException;
import com.example.BMS.repo.EmployeeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class employeeService {

    @Autowired
    private EmployeeRepo employeeRepo;

    //To create employee
    public Employee saveEmployee(Employee employee) {
        return employeeRepo.save(employee);
    }
    
  //To update employee
    public Employee updateEmployee(Long emp_id, Employee employee) {
        Optional<Employee> existingEmployeeOptional = employeeRepo.findById(emp_id);

        if (existingEmployeeOptional.isPresent()) {
            Employee existingEmp = existingEmployeeOptional.get();

            existingEmp.setEmp_id(employee.getEmp_id());
            existingEmp.setName(employee.getName());
            existingEmp.setPosition(employee.getPosition());
            existingEmp.setSalary(employee.getSalary());
      
            return employeeRepo.save(existingEmp);
        } else {
            return null;
        }
    }

    // Get all employees
    public List<Employee> getAllEmployee() {
        return employeeRepo.findAll();
    }

    // Get employee by their ID
    public Employee getEmployeeById(Long emp_id) {
        Optional<Employee> employee = employeeRepo.findById(emp_id);
        if (employee.isPresent()) {
            return employee.get();
        } else {
            throw new ResourceNotFoundException("Employee not found with id: " + emp_id);
        }
    }

    // Delete employee by ID
    public void deleteEmployee(Long emp_id) {
        Optional<Employee> employee = employeeRepo.findById(emp_id);
        if (employee.isPresent()) {
            employeeRepo.deleteById(emp_id);
        } else {
            throw new ResourceNotFoundException("Employee not found with id: " + emp_id);
        }
    }
}
