package com.example.BMS.entity;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@Table(name="account")
@Getter
@Setter
public class Account {
	@Id 
    private Long acc_id;
    
    @Column(length=10,nullable=false)
    @NotNull(message="Enter the amount")
    @Positive(message="The amount entered should be positive")
    private Double balance;
}
