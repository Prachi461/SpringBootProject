package com.example.BMS.controller;

import com.example.BMS.entity.Branch;
import com.example.BMS.service.branchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/branch")
public class branchController {

    @Autowired
    private branchService branchService;

    // Create Branch
    @PostMapping
    public ResponseEntity<Branch> createOrUpdateBranch(@RequestBody Branch branch) {
        Branch savedBranch = branchService.saveBranch(branch);
        return new ResponseEntity<>(savedBranch, HttpStatus.CREATED);
    }
    
 // Update branch details
    @PutMapping("/{id}")
    public ResponseEntity<Branch> updateBranch(@PathVariable("id") Long branch_id, @RequestBody Branch branch) {
        Branch updatedBranch = branchService.updateBranch(branch_id, branch);

        if (updatedBranch == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(updatedBranch, HttpStatus.OK);
    }

    // Get all branch details
    @GetMapping
    public ResponseEntity<List<Branch>> getAllBranches() {
        List<Branch> branch = branchService.getAllBranches();
        return new ResponseEntity<>(branch, HttpStatus.OK);
    }

    // Get any branch by ID
    @GetMapping("/{id}")
    public ResponseEntity<Branch> getBranchById(@PathVariable("id") Long branch_id) {
        Branch branch = branchService.getBranchById(branch_id);
        return new ResponseEntity<>(branch, HttpStatus.OK);
    }

    // Delete branch by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBranch(@PathVariable("id") Long branch_id) {
        branchService.deleteBranch(branch_id);
        return new ResponseEntity<>("Branch has been deleted successfully!", HttpStatus.NO_CONTENT);
    }
}
