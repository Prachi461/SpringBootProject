package com.example.BMS.service;

import com.example.BMS.entity.Account;
import com.example.BMS.exception.ResourceNotFoundException;
import com.example.BMS.repo.AccountRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class accountService {

    @Autowired
    private AccountRepo accountRepo;

    //To create an account
    public Account saveAccount(Account account) {
        return accountRepo.save(account);
    }
    
  //To update any account by ID
    public Account updateAccount(Long acc_id, Account account) {
        Optional<Account> existingAccountOptional = accountRepo.findById(acc_id);

        if (existingAccountOptional.isPresent()) {
            Account existingAccount = existingAccountOptional.get();

            existingAccount.setAcc_id(account.getAcc_id());
            existingAccount.setBalance(account.getBalance());
      
            return accountRepo.save(existingAccount);
        } else {
            return null;
        }
    }

    // Get all accounts
    public List<Account> getAllAccounts() {
        return accountRepo.findAll();
    }

    // Get account by ID
    public Account getAccountById(Long acc_id) {
        Optional<Account> account = accountRepo.findById(acc_id);
        if (account.isPresent()) {
            return account.get();
        } else {
            throw new ResourceNotFoundException("Account not found with id: " + acc_id);
        }
    }

    // Delete account by ID
    public void deleteAccount(Long acc_id) {
        Optional<Account> account = accountRepo.findById(acc_id);
        if (account.isPresent()) {
            accountRepo.deleteById(acc_id);
        } else {
            throw new ResourceNotFoundException("Account not found with id: " + acc_id);
        }
    }
}
